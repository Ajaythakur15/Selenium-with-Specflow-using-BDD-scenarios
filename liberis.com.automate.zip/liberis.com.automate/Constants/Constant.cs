﻿using System;
using System.Collections.Generic;
using System.Text;

namespace liberis.com.automate.Constant
{
    public class Constant
    {
        public const string Broker = "I'm a Broker";
        public const string ISO = "I'm an ISO";
        public const string Partner = "I'm a Strategic Partner";
        public const string Becomeapartner="become-a-partner";
        public const string SelectTypeOfPartner = "Please select a type of partner";
        public const string Title = "liberis";


    }
}
